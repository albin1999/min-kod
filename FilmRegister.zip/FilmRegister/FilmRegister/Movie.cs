﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FilmRegister
{
	class Movie
	{
		public string Title;
		public string Genre;
		public int ReleaseYear;

	}
}

