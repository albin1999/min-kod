﻿using System;
using System.IO;
using System.Linq;
using System.Text;

namespace FilmRegister
{
	class Program
	{
		//Declare array for all methods. Done to minimize redundancy.
		public static Movie[] movieList = new Movie[0];
		static void Main(string[] args)
		{
			Console.WriteLine("My movies\n\nINSTRUCTIONS.");
			ReadMovies();
			ShowMenu();
		}

		/// <summary>
		/// Gives user a menu option and parse their choice and start the method of choice.
		/// </summary>
		public static void ShowMenu()
		{
			bool done = false;
			while (done == false)
			{
				//Print instuctions.
				Console.WriteLine("Press: [1] to see all movies.\nPress: [2] to sort movies by realease date.\nPress: [3] to sort movies by genre.\nPress: [4] to add a movie to the list.\nPress: [5] to remove a movie from the list.\nPress: [6] to exit and save.");
				string userInput = Console.ReadLine();
				//If it can parse.
				if (Int32.TryParse(userInput, out int val))
				{
					int menuInput = int.Parse(userInput);

					switch (menuInput)
					{
						case 1:
							PrintMovieList(movieList);
							break;

						case 2:
							SortByYear();
                            Console.WriteLine("\nSORTING ARRAY....\n");
							break;

						case 3:
							SortByGenre();
							Console.WriteLine("\nSORTING ARRAY....\n");
							break;

						case 4:
							AddMovie();
							break;

						case 5:
							RemoveMovie(movieList);
							break;

						case 6:
							done = true;
							SaveToFile(movieList);
							break;

						default:
							Console.WriteLine("Error");
							break;
					}
					

				}
				//Parse error.
				else
				{
					Console.WriteLine("Error try again!");
				}
			}
			
		}
		/// <summary>
		/// Add movie obj to movieList.
		/// </summary>
		/// <param name="newMovie">Movie to add</param>
		/// <returns>Return new movie array.</returns>
		public static Movie[] AddMovieToArray(Movie newMovie)
		{
			Movie[] movieVector = new Movie[movieList.Length + 1];
			//Copies current list with one more index.
			for (int i = 0; i < movieList.Length; i++)
			{
				movieVector[i] = movieList[i];
			}
			movieVector[movieList.Length] = newMovie;
			return movieVector;
		}

		/// <summary>
		/// User inputs a movie to the movieList array.
		/// </summary>
		public static void AddMovie()
		{
			//movie object to add to array.
			Movie movie = new Movie();

			//Made smaller methods to make the code readable.
			movie.Title = UserInputTitle();
			movie.Genre = UserInputGenre();
			movie.ReleaseYear = UserInputYear();
			//Adds movie to array and extend the array.
			movieList = AddMovieToArray(movie);
			Console.WriteLine("NEW MOVIE ADDED.....");
		}

		/// <summary>
		/// Reads movies.txt file and gives the value to the movieList array.
		/// </summary>
		public static void ReadMovies()
		{
			StreamReader textfile = new StreamReader("movies.txt");
			while (true)
			{
				string Line = textfile.ReadLine();
				//If there isnt a line it breaks.
				if (Line == null) break;

				//Save movie info in movieInfo.
				var movieInfo = Line.Split("/");
				//makes new object for each line
				Movie movie = new Movie();
				//first index in movieInfo is Title.
				movie.Title = movieInfo[0];
				//second index in movieInfo is Genre.
				movie.Genre = movieInfo[1];
				//third index in movieInfo is ReleaseYear.
				movie.ReleaseYear = int.Parse(movieInfo[2]);

				movieList = AddMovieToArray(movie);
			}
			textfile.Close();
		}

		/// <summary>
		/// User inputs title.
		/// </summary>
		/// <returns>Title</returns>
		public static string UserInputTitle()
		{
			while (true)
			{
				Console.WriteLine("Title: ");
				string titleInput = Console.ReadLine();
				if (titleInput.Length < 1)
				{
					Console.WriteLine("Eroror please enter in title.");
					continue;
				}
				else if(titleInput.Length > 20)
				{
					Console.WriteLine("\nToo long title.\n");
					continue;
				}
				return titleInput;
			}
		}
		/// <summary>
		/// User inputs year.
		/// </summary>
		/// <returns>year</returns>
		public static int UserInputYear()
		{
			int year;
			while (true)
			{
				Console.WriteLine("Release Year: ");
				string yearInput = Console.ReadLine();
				//Checks if input can parse to int. So it wont be a problem with sorting later.
				if (Int32.TryParse(yearInput, out int val))
				{
					year = int.Parse(yearInput);
					break;
				}
				else
				{
					Console.WriteLine($"Error: ({yearInput}) isn't a number");
				}
			}
			return year;
		}
		/// <summary>
		/// User inputs genre option from genreList.
		/// </summary>
		/// <returns>Genre</returns>
		public static string UserInputGenre()
		{
			string[] genreList = new string[] { "Action", "Comedy", "Drama", "Fantasy", "Horror", "Mystery", "Romance", "Thriller", "Western" };
			string genre;
			while (true) 
			{
				Console.WriteLine("Enter in genre: Use index.");
				for (int i = 0; i < genreList.Length; i++)
				{
					Console.WriteLine($"{genreList[i]} :Index[{i}]");
				}
				string genreNotParseInput = Console.ReadLine();

				//Checks if you can prase input.
				if (Int32.TryParse(genreNotParseInput, out int val))
				{
					//Parse input to int
					int genreInput = int.Parse(genreNotParseInput);
					if (genreInput < movieList.Length && genreInput >= 0)
					{
						genre = genreList[genreInput];
						break;
					}

					//Large/small int.
					else
					{
						Console.WriteLine("\nError\n");
						continue;
					}
				}
				//Parse error.
				else
				{
					Console.WriteLine("\nError try again!\n");
					continue;
				}
			}
			return genre;
		}
		/// <summary>
		/// Save the current movieList array to the movies.txt file.
		/// </summary>
		/// <param name="inputList">movieList</param>
		public static void SaveToFile(Movie[] inputList)
		{
			StreamWriter textfile = new StreamWriter("movies.txt");

			//Write to movies.txt
			for (int i = 0; i < movieList.Length; i++)
			{
				textfile.WriteLine(movieList[i].Title + "/" + movieList[i].Genre + "/" + movieList[i].ReleaseYear);
			}
			Console.WriteLine("SAVED FILE.....");
			//Close file.
			textfile.Close();
		}

		/// <summary>
		/// Bubble sort with realease year.
		/// </summary>
		public static void SortByYear()
		{
			//Temporary variables to change index in array.
			Movie tempMovie = new Movie();
			
			//Bubble sort 2D
			for (int i = 0; i < movieList.Length; i++)
			{
				for (int x = 0; x < movieList.Length - 1; x++)
				{
					if (movieList[x].ReleaseYear > movieList[x + 1].ReleaseYear)
					{
						//Swap place.
						tempMovie = movieList[x + 1];
						movieList[x + 1] = movieList[x];
						movieList[x] = tempMovie;
					}
				}
			}
		}

		/// <summary>
		/// Removes movie from movieList array.
		/// </summary>
		/// <param name="listOfMovies">List of movies to remove one movie</param>
		public static void RemoveMovie(Movie[] listOfMovies)
		{
			//New array with one less index than the input array.
			Movie[] newMovieList = new Movie[listOfMovies.Length - 1];
			//Declare object to help repositioning of array index.
			Movie temp = new Movie();
			int indexToRemove;
			while (true)
			{
				PrintMovieList(movieList);
				Console.WriteLine("What movie do you want to remove? Use index.");
				string input = Console.ReadLine();

				if(Int32.TryParse(input, out indexToRemove))
					{
					indexToRemove = int.Parse(input);
					//Checks if indexs is valid.
					if (indexToRemove <= movieList.Length && indexToRemove >= 0)
					{
						break;
					}
					else
					{
						Console.WriteLine("\nError invalid number.\n");
					}
				}
				//Parse error.
				else
				{
					Console.WriteLine("\nError parsing error.\n");
				}
			}

			int counter = 0;
			//Checks if i is not the movie to remove and adds it to a new array. If the index is the movie to removie it wont add it to the new array.
			for (int i = 0; i < listOfMovies.Length; i++)
			{
				//If indexToRemove isnt equal to i then it adds to the new array.
				if (indexToRemove != i)
				{
					newMovieList[counter] = listOfMovies[i];
					counter++;
				}
			}
			movieList = newMovieList;
			Console.WriteLine("REMOVED MOVIE.....");
		}
		/// <summary>
		/// Prints array of movies.
		/// </summary>
		/// <param name="movieList">The public movie list</param>
		public static void PrintMovieList(Movie[] movieList)
		{
			Console.Clear();
			Movie movie = new Movie();
			Console.WriteLine("-----------------------------------------------------------------------|");
			Console.WriteLine("Title                | Genre           | Release Date       |   Index  |");
			Console.WriteLine("-----------------------------------------------------------------------|");
			for (int i = 0; i < movieList.Length; i++)
			{
				movie = movieList[i];
				Console.WriteLine(String.Format("{0,-20} | {1,-15} | {2,5}              |{3,6}    |", movie.Title, movie.Genre, movie.ReleaseYear, i));
			}
			Console.WriteLine("-----------------------------------------------------------------------|");
		}

		/// <summary>
		/// Sort movie by genre.
		/// </summary>
		public static void SortByGenre()
		{
			//Genre list
			string[] genreList = new string[] { "Action", "Comedy", "Drama", "Fantasy", "Horror", "Mystery", "Romance", "Thriller", "Western" };
			Movie movie = new Movie();
			Movie[] sortedMovieList = new Movie[movieList.Length];
			int index = 0;
			//Rearrange the position of the movie based on what genre the movie has.
			for (int i = 0; i < genreList.Length; i++)
			{
				for (int z = 0; z < movieList.Length; z++)
				{
					if (movieList[z].Genre == genreList[i])
					{
						sortedMovieList[index] = movieList[z];
						index++;
					}
				}
			}
			//Movielist sorted.
			movieList = sortedMovieList;
		}
	}
}
